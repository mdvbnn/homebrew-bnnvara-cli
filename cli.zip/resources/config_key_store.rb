class ConfigKeyStore

  SETUP_RUN = 'setup.run'

  PROJECT_DIR = 'project.dir'
  PROJECT_ACTIVE = 'project.active'

  DOCKER_ACTIVE = 'docker.active'

  GIT_CLONE_METHOD = 'git.clone_method'

end